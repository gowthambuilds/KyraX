import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, MediaGalleryItemBuilder, AttachmentBuilder } from 'discord.js';
import { TicketUI } from '#classes/TicketUI';
import path from 'path';

export default {
    name: 'getaccess',
    description: 'Instructions on how to get access to free codes and bots',
    async execute({ client, message, interaction }) {
        const isSlash = !!interaction;
        const guild = isSlash ? interaction.guild : message.guild;

        const settings = await client.db.getSettings(guild.id);
        const verifyChannelId = settings.verificationChannelId;
        const targetUrl = 'https://www.youtube.com/@nextraforgestudios';

        const container = new ContainerBuilder();

        const channelMention = verifyChannelId ? `<#${verifyChannelId}>` : 'the designated verification channel';

        const content = `## 🚀 Get Exclusive Access!\nUnlock our **free bot and web codes** by following these simple steps:\n\n1. **Subscribe** to our YouTube channel: [Nextra Forge Studios](${targetUrl})\n2. **Capture a screenshot** showing your subscription.\n3. **Post the screenshot** in ${channelMention} for automatic verification.\n\nOnce verified, you'll receive the subscriber role and instant access to our exclusive resources! 🔥`;

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(content)
        );

        container.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel('Subscribe Here')
                .setURL(targetUrl)
                .setStyle(ButtonStyle.Link),
            new ButtonBuilder()
                .setLabel('Support Server')
                .setURL(client.config.bot.supportServer)
                .setStyle(ButtonStyle.Link)
        );

        container.addActionRowComponents(row);

        // Add the image gallery at the bottom
        const imagePath = path.resolve('data/assets/getaccess.png');
        const attachment = new AttachmentBuilder(imagePath, { name: 'getaccess.png' });

        const gallery = new MediaGalleryBuilder()
            .addItems(
                new MediaGalleryItemBuilder()
                    .setURL('attachment://getaccess.png')
            );

        container.addMediaGalleryComponents(gallery);

        const responseData = { components: [container], files: [attachment], flags: TicketUI.getFlags() };

        if (isSlash) {
            await interaction.reply(responseData);
        } else {
            await message.reply(responseData);
        }
    }
};
